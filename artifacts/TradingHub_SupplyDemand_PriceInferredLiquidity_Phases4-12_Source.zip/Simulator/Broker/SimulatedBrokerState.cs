using Brokers.Models;
using ChartAnnotator.Collections;
using ChartAnnotator.Models;
using Simulator.Models;
using Simulator.Execution;

namespace Simulator.Broker;

internal sealed class SimulatedBrokerState
{
    private readonly object _sync = new();
    private readonly SimulationOptions _options;
    private readonly Dictionary<string, SimulatedOrder> _orders = new(StringComparer.Ordinal);
    private readonly Dictionary<string, SimulatedAmendmentReceipt> _stopAmendments =
        new(StringComparer.Ordinal);
    private readonly Dictionary<InstrumentKey, MutablePosition> _positions = [];
    private readonly Dictionary<ChartKey, RingBuffer<Candle>> _candles = [];
    private readonly Dictionary<InstrumentKey, Candle> _latestCandles = [];
    private readonly RingBuffer<LedgerEntry> _ledger;
    private long _ledgerSequence;
    private long _orderSequence;
    private long _executionFillCount;
    private decimal _totalSpreadPrice;
    private decimal _totalSlippagePrice;
    private long _stopFillCount;
    private decimal _totalStopSlippagePrice;
    private int _gapFills;
    private int _partialFills;
    private int _rejectedAmendments;

    public SimulatedBrokerState(SimulationOptions options)
    {
        _options = options;
        CashBalance = options.StartingBalance;
        _ledger = new RingBuffer<LedgerEntry>(options.LedgerCapacity);
        AddLedgerUnsafe(
            DateTimeOffset.MinValue,
            LedgerEntryType.Deposit,
            options.StartingBalance,
            null,
            "Starting simulation balance");
    }

    public decimal CashBalance { get; private set; }
    public decimal TotalCommission { get; private set; }
    public int SubmittedOrders { get; private set; }
    public int FilledOrders { get; private set; }
    public int RejectedOrders { get; private set; }
    public long MarketSequence { get; private set; }

    public long AdvanceMarket(Candle candle)
    {
        lock (_sync)
        {
            MarketSequence++;
            _latestCandles[candle.Instrument] = candle;
            return MarketSequence;
        }
    }

    public void RecordCandle(Candle candle)
    {
        lock (_sync)
        {
            ChartKey key = new(candle.Instrument, candle.Interval);
            if (!_candles.TryGetValue(key, out RingBuffer<Candle>? buffer))
            {
                buffer = new RingBuffer<Candle>(_options.CandleCapacity);
                _candles.Add(key, buffer);
            }

            buffer.Add(candle);
            _latestCandles[candle.Instrument] = candle;
        }
    }

    public IReadOnlyList<Candle> GetCandles(CandleQuery query)
    {
        query.Validate(_options.CandleCapacity, "Simulator");
        lock (_sync)
        {
            ChartKey key = new(query.Instrument, query.Interval);
            if (!_candles.TryGetValue(key, out RingBuffer<Candle>? buffer))
            {
                return [];
            }

            IEnumerable<Candle> result = buffer;
            if (query.From is not null)
            {
                result = result.Where(candle => candle.OpenTime >= query.From.Value);
            }

            if (query.To is not null)
            {
                result = result.Where(candle => candle.OpenTime <= query.To.Value);
            }

            return result.TakeLast(query.Limit).ToArray();
        }
    }

    public SimulatedOrder CreateOrder(PlaceOrderRequest request, DateTimeOffset now, string? ocoGroupId = null)
    {
        lock (_sync)
        {
            return CreateOrderUnsafe(request, now, ocoGroupId);
        }
    }

    public bool TryCreateOrder(
        PlaceOrderRequest request,
        DateTimeOffset now,
        out SimulatedOrder? order,
        out string? error)
    {
        lock (_sync)
        {
            if (_options.ExecutionModel.StressScenario == StressExecutionScenario.CombinedStress &&
                request.ReduceOnly &&
                (MarketSequence + _options.ExecutionModel.DeterministicSeed) % 13 == 0)
            {
                order = null;
                error = "OperationFaultInjected: deterministic close rejection.";
                return false;
            }
            if (_options.ExecutionModel.StressScenario is
                    StressExecutionScenario.ConnectionLoss or StressExecutionScenario.CombinedStress &&
                (MarketSequence + _options.ExecutionModel.DeterministicSeed) % 17 == 0)
            {
                order = null;
                error = "OperationFaultInjected: deterministic simulated connection loss.";
                return false;
            }
            if (_options.ExecutionModel.StressScenario == StressExecutionScenario.CombinedStress &&
                (MarketSequence + _options.ExecutionModel.DeterministicSeed) % 19 == 0)
            {
                order = null;
                error = "OperationFaultInjected: deterministic simulated rate limit.";
                return false;
            }
            if (_options.ExecutionModel.StressScenario == StressExecutionScenario.CombinedStress &&
                (MarketSequence + _options.ExecutionModel.DeterministicSeed) % 23 == 0)
            {
                order = null;
                error = "OperationFaultInjected: deterministic stale quote rejection.";
                return false;
            }
            if (request.ClientOrderId is not null && _orders.Values.Any(existing =>
                    string.Equals(
                        existing.ClientOrderId,
                        request.ClientOrderId,
                        StringComparison.Ordinal)))
            {
                order = null;
                error = $"Client order ID '{request.ClientOrderId}' has already been used.";
                return false;
            }

            order = CreateOrderUnsafe(request, now);
            error = null;
            return true;
        }
    }

    public void RejectOrder()
    {
        lock (_sync)
        {
            SubmittedOrders++;
            RejectedOrders++;
        }
    }

    public string? GetOrderConfigurationError(PlaceOrderRequest request)
    {
        lock (_sync)
        {
            return TryGetQuoteToBaseCurrencyRateUnsafe(
                request.Instrument,
                out _,
                out string? error)
                ? null
                : error;
        }
    }

    public decimal GetQuoteToBaseCurrencyRate(InstrumentKey instrument)
    {
        lock (_sync)
        {
            if (TryGetQuoteToBaseCurrencyRateUnsafe(instrument, out decimal rate, out string? error))
            {
                return rate;
            }

            throw new InvalidOperationException(error);
        }
    }

    public bool TryGetQuoteToBaseCurrencyRate(
        InstrumentKey instrument,
        out decimal rate,
        out string? error)
    {
        lock (_sync)
        {
            return TryGetQuoteToBaseCurrencyRateUnsafe(instrument, out rate, out error);
        }
    }

    public bool TryCancel(string brokerOrderId, out SimulatedOrder? cancelled)
    {
        lock (_sync)
        {
            if (!_orders.TryGetValue(brokerOrderId, out SimulatedOrder? order) || !order.IsOpen)
            {
                cancelled = null;
                return false;
            }

            order.Status = "CANCELLED";
            cancelled = order.Copy();
            return true;
        }
    }

    public SimulatedProtectiveStopReplacement AmendProtectiveStop(
        AmendProtectiveStopRequest request,
        DateTimeOffset acceptedAt)
    {
        lock (_sync)
        {
            if (_options.ExecutionModel.StressScenario is
                StressExecutionScenario.StopAmendmentFailure or StressExecutionScenario.CombinedStress)
            {
                return RejectedReplacement(request,
                    "OperationFaultInjected: deterministic stop-amendment failure.");
            }
            if (_stopAmendments.TryGetValue(request.ClientAmendmentId, out SimulatedAmendmentReceipt? receipt))
            {
                if (receipt.Request == request)
                {
                    return new SimulatedProtectiveStopReplacement(
                        receipt.Result,
                        null,
                        null,
                        IsReplay: true);
                }

                return RejectedReplacement(
                    request,
                    "The amendment ID was already used with a different payload.");
            }

            string? validationError = ValidateProtectiveStopAmendmentUnsafe(request);
            if (validationError is not null)
            {
                SimulatedProtectiveStopReplacement rejected = RejectedReplacement(request, validationError);
                _stopAmendments[request.ClientAmendmentId] =
                    new SimulatedAmendmentReceipt(request, rejected.Result);
                return rejected;
            }

            SimulatedOrder previous = _orders[request.ExistingStopOrderId!];
            var replacementRequest = previous.Request with
            {
                StopPrice = request.NewStopPrice,
                ClientOrderId = request.ClientAmendmentId
            };
            SimulatedOrder current = CreateOrderUnsafe(
                replacementRequest,
                acceptedAt,
                previous.OcoGroupId);

            // Both mutations occur under the same state lock. The target remains in
            // the original OCO group and there is no observable unprotected state.
            previous.Status = "REPLACED";
            var result = new ProtectiveStopAmendmentResult
            {
                Status = ProtectiveStopAmendmentStatus.Replaced,
                ClientAmendmentId = request.ClientAmendmentId,
                PreviousStopOrderId = previous.BrokerOrderId,
                CurrentStopOrderId = current.BrokerOrderId,
                RequestedStopPrice = request.NewStopPrice,
                AcceptedStopPrice = request.NewStopPrice,
                AcceptedAt = acceptedAt,
                EffectiveFromExecutionSequence = request.EffectiveFromExecutionSequence,
                Certainty = ExecutionCertainty.Accepted
            };
            _stopAmendments[request.ClientAmendmentId] =
                new SimulatedAmendmentReceipt(request, result);
            return new SimulatedProtectiveStopReplacement(
                result,
                previous.Copy(),
                current.Copy(),
                IsReplay: false);
        }
    }

    public bool TryExpire(string brokerOrderId, out SimulatedOrder? expired)
    {
        lock (_sync)
        {
            if (!_orders.TryGetValue(brokerOrderId, out SimulatedOrder? order) || !order.IsOpen)
            {
                expired = null;
                return false;
            }

            order.Status = "EXPIRED";
            expired = order.Copy();
            return true;
        }
    }

    public IReadOnlyList<SimulatedOrder> GetEligibleOrders(
        InstrumentKey instrument,
        decimal? candleOpen = null)
    {
        lock (_sync)
        {
            IEnumerable<SimulatedOrder> open = _orders.Values
                .Where(order =>
                    order.IsOpen &&
                    order.Request.Instrument == instrument &&
                    order.SubmittedMarketSequence < MarketSequence);

            // Nearest-to-open: sort by distance first; exact ties use stop-first.
            // Conservative/optimistic: sort by policy priority only.
            IOrderedEnumerable<SimulatedOrder> ordered =
                _options.OcoFillPolicy == OcoFillPolicy.NearestToOpenFirst
                    ? open
                        .OrderBy(GetExecutionPhasePriority)
                        .ThenBy(order => order.SubmittedMarketSequence)
                        .ThenBy(order => GetNearestDistance(order, candleOpen))
                        .ThenBy(order => GetOcoExecutionPriority(order, candleOpen))
                        .ThenBy(order => order.BrokerOrderId, StringComparer.Ordinal)
                    : open
                        .OrderBy(GetExecutionPhasePriority)
                        .ThenBy(order => order.SubmittedMarketSequence)
                        .ThenBy(order => GetOcoExecutionPriority(order, candleOpen))
                        .ThenBy(order => order.BrokerOrderId, StringComparer.Ordinal);

            return ordered.Select(order => order.Copy()).ToArray();
        }
    }

    public bool MarkTriggered(string brokerOrderId)
    {
        lock (_sync)
        {
            if (!_orders.TryGetValue(brokerOrderId, out SimulatedOrder? order) || !order.IsOpen)
            {
                return false;
            }

            order.IsTriggered = true;
            order.SubmittedMarketSequence = MarketSequence;
            order.Status = "TRIGGERED";
            return true;
        }
    }

    public bool TryApplyFill(
        string brokerOrderId,
        decimal price,
        decimal quantity,
        decimal commission,
        DateTimeOffset timestamp,
        out FillApplicationResult? result,
        out SimulatedOrder? rejectedOrder,
        out string? rejectionReason)
    {
        lock (_sync)
        {
            result = null;
            rejectedOrder = null;
            rejectionReason = null;

            if (!_orders.TryGetValue(brokerOrderId, out SimulatedOrder? order) || !order.IsOpen)
            {
                return false;
            }

            decimal remainingQuantity = order.Request.Quantity.Value - order.FilledQuantity;
            if (quantity <= 0m || quantity > remainingQuantity)
            {
                rejectionReason =
                    $"Fill quantity {quantity} exceeds the order's remaining quantity {remainingQuantity}.";
                order.Status = "REJECTED";
                RejectedOrders++;
                rejectedOrder = order.Copy();
                return false;
            }

            bool reduceOnlyClamped = false;
            if (order.Request.ReduceOnly)
            {
                if (!_positions.TryGetValue(order.Request.Instrument, out MutablePosition? reducible) ||
                    reducible.SignedQuantity == 0m)
                {
                    rejectionReason = "A reduce-only order requires an open position.";
                    order.Status = "REJECTED";
                    RejectedOrders++;
                    rejectedOrder = order.Copy();
                    return false;
                }

                decimal signedRequest = order.Request.Side == OrderSide.Buy ? quantity : -quantity;
                if (Math.Sign(signedRequest) == Math.Sign(reducible.SignedQuantity))
                {
                    rejectionReason = "A reduce-only order cannot increase the current position.";
                    order.Status = "REJECTED";
                    RejectedOrders++;
                    rejectedOrder = order.Copy();
                    return false;
                }

                decimal reducibleQuantity = Math.Abs(reducible.SignedQuantity);
                if (quantity > reducibleQuantity)
                {
                    quantity = reducibleQuantity;
                    reduceOnlyClamped = true;
                    decimal quoteToBaseForCommission =
                        GetQuoteToBaseCurrencyRateUnsafe(order.Request.Instrument);
                    commission = Math.Abs(price * quantity) * quoteToBaseForCommission *
                        _options.CommissionRate;
                }
            }

            rejectionReason = GetMarginRejectionReasonUnsafe(order, price, quantity, commission);
            if (rejectionReason is not null)
            {
                order.Status = "REJECTED";
                RejectedOrders++;
                rejectedOrder = order.Copy();
                return false;
            }

            order.FilledQuantity += quantity;
            if (reduceOnlyClamped)
            {
                // The unfilled remainder is cancelled by reduce-only semantics because the
                // position is now flat; represent the broker order as terminal.
                order.FilledQuantity = order.Request.Quantity.Value;
            }
            order.Status = order.FilledQuantity >= order.Request.Quantity.Value
                ? "FILLED"
                : "PARTIALLY_FILLED";

            if (order.Status == "FILLED")
            {
                FilledOrders++;
            }

            decimal signedFill = order.Request.Side == OrderSide.Buy ? quantity : -quantity;
            bool reducesExistingPosition = _positions.TryGetValue(
                    order.Request.Instrument,
                    out MutablePosition? existingPosition) &&
                existingPosition.SignedQuantity != 0m &&
                Math.Sign(existingPosition.SignedQuantity) != Math.Sign(signedFill);
            decimal quoteToBaseRate = GetQuoteToBaseCurrencyRateUnsafe(order.Request.Instrument);
            decimal realised = ApplyPositionFillUnsafe(
                order.Request,
                signedFill,
                price) * quoteToBaseRate;
            BrokerPosition? positionAfterFill = GetPositionUnsafe(order.Request.Instrument);
            ProtectiveOrderReconciliation reconciliation = reducesExistingPosition
                ? ReconcileProtectiveOrdersUnsafe(
                    order.Request.Instrument,
                    positionAfterFill,
                    order.BrokerOrderId)
                : ProtectiveOrderReconciliation.Empty;

            CashBalance += realised - commission;
            TotalCommission += commission;

            if (commission != 0m)
            {
                AddLedgerUnsafe(
                    timestamp,
                    LedgerEntryType.Commission,
                    -commission,
                    order.BrokerOrderId,
                    "Execution commission");
            }

            if (realised != 0m || reducesExistingPosition)
            {
                AddLedgerUnsafe(
                    timestamp,
                    LedgerEntryType.RealisedProfitLoss,
                    realised,
                    order.BrokerOrderId,
                    "Realised position profit/loss");
            }

            result = new FillApplicationResult(
                order.Copy(),
                realised,
                commission,
                positionAfterFill,
                reconciliation.ResizedOrders,
                reconciliation.CancelledOrders,
                quantity);
            return true;
        }
    }

    public IReadOnlyList<SimulatedOrder> CancelOcoSiblings(string filledOrderId)
    {
        lock (_sync)
        {
            if (!_orders.TryGetValue(filledOrderId, out SimulatedOrder? filled) ||
                string.IsNullOrWhiteSpace(filled.OcoGroupId))
            {
                return [];
            }

            SimulatedOrder[] siblings = _orders.Values
                .Where(order =>
                    order.BrokerOrderId != filledOrderId &&
                    order.IsOpen &&
                    string.Equals(order.OcoGroupId, filled.OcoGroupId, StringComparison.Ordinal))
                .ToArray();

            foreach (SimulatedOrder sibling in siblings)
            {
                sibling.Status = "CANCELLED";
            }

            return siblings.Select(order => order.Copy()).ToArray();
        }
    }

    public IReadOnlyList<SimulatedOrder> ResizeOpenOcoGroupQuantities(
        string ocoGroupId,
        decimal totalQuantity)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ocoGroupId);
        if (totalQuantity <= 0m) throw new ArgumentOutOfRangeException(nameof(totalQuantity));
        lock (_sync)
        {
            SimulatedOrder[] orders = _orders.Values
                .Where(order => order.IsOpen &&
                    string.Equals(order.OcoGroupId, ocoGroupId, StringComparison.Ordinal))
                .OrderBy(order => order.BrokerOrderId, StringComparer.Ordinal)
                .ToArray();
            foreach (SimulatedOrder order in orders)
            {
                if (totalQuantity < order.FilledQuantity)
                    throw new InvalidOperationException("A protective order cannot be resized below its filled quantity.");
                order.Request = order.Request with
                {
                    Quantity = new OrderQuantity(totalQuantity, order.Request.Quantity.Unit)
                };
            }
            return orders.Select(order => order.Copy()).ToArray();
        }
    }

    internal SimulatedOrder? GetSimulatedOrder(string brokerOrderId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(brokerOrderId);
        lock (_sync)
        {
            return _orders.TryGetValue(brokerOrderId, out SimulatedOrder? order)
                ? order.Copy()
                : null;
        }
    }

    internal BrokerOrder? GetOrder(string brokerOrderId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(brokerOrderId);
        lock (_sync)
        {
            return _orders.TryGetValue(brokerOrderId, out SimulatedOrder? order)
                ? ToBrokerOrder(order)
                : null;
        }
    }

    public IReadOnlyList<BrokerOrder> GetOpenOrders(InstrumentKey? instrument)
    {
        lock (_sync)
        {
            return _orders.Values
                .Where(order => order.IsOpen && (instrument is null || order.Request.Instrument == instrument.Value))
                .Select(ToBrokerOrder)
                .ToArray();
        }
    }

    public IReadOnlyList<BrokerPosition> GetPositions()
    {
        lock (_sync)
        {
            return _positions.Values.Select(ToBrokerPositionUnsafe).ToArray();
        }
    }

    public AccountSnapshot GetAccount()
    {
        lock (_sync)
        {
            decimal unrealised = _positions.Values.Sum(position => CalculateUnrealisedUnsafe(position));
            decimal margin = _positions.Values.Sum(position => CalculateMarginUnsafe(position));
            return new AccountSnapshot
            {
                AccountId = _options.AccountId,
                AccountType = "Simulated Margin",
                Currency = _options.BaseCurrency,
                Balance = CashBalance,
                Available = CashBalance + unrealised - margin,
                MarginUsed = margin,
                UnrealizedProfitLoss = unrealised,
                CanTrade = CashBalance + unrealised - margin > 0m
            };
        }
    }

    public SimulationResult BuildResult(DateTimeOffset startedAt, DateTimeOffset endedAt)
    {
        lock (_sync)
        {
            decimal unrealised = _positions.Values.Sum(position => CalculateUnrealisedUnsafe(position));
            decimal equity = CashBalance + unrealised;
            return new SimulationResult
            {
                StartedAt = startedAt,
                EndedAt = endedAt,
                StartingBalance = _options.StartingBalance,
                FinalBalance = CashBalance,
                FinalEquity = equity,
                UnrealizedProfitLoss = unrealised,
                NetProfit = equity - _options.StartingBalance,
                TotalCommission = TotalCommission,
                SubmittedOrders = SubmittedOrders,
                FilledOrders = FilledOrders,
                RejectedOrders = RejectedOrders,
                OpenPositions = _positions.Values.Select(ToBrokerPositionUnsafe).ToArray(),
                Ledger = _ledger.Snapshot(),
                ExecutionPerformance = new SimulationExecutionPerformance
                {
                    AverageSpreadPrice = _executionFillCount == 0 ? 0m : _totalSpreadPrice / _executionFillCount,
                    AverageSlippagePrice = _executionFillCount == 0 ? 0m : _totalSlippagePrice / _executionFillCount,
                    AverageStopSlippagePrice = _stopFillCount == 0 ? 0m : _totalStopSlippagePrice / _stopFillCount,
                    GapFills = _gapFills,
                    PartialFills = _partialFills,
                    RejectedAmendments = _rejectedAmendments,
                    FinancingTotal = _ledger.Where(item => item.Type == LedgerEntryType.Financing).Sum(item => item.Amount)
                }
            };
        }
    }

    public IReadOnlyList<LedgerEntry> GetLedger()
    {
        lock (_sync)
        {
            return _ledger.Snapshot();
        }
    }

    public void ApplyFinancing(DateTimeOffset timestamp, decimal amount, string description)
    {
        lock (_sync)
        {
            CashBalance += amount;
            AddLedgerUnsafe(timestamp, LedgerEntryType.Financing, amount, null, description);
        }
    }

    public void RecordExecutionFill(
        StandardOrderType orderType,
        FillEvaluation evaluation)
    {
        ArgumentNullException.ThrowIfNull(evaluation);
        lock (_sync)
        {
            _executionFillCount++;
            _totalSpreadPrice += evaluation.AppliedSpreadPrice;
            _totalSlippagePrice += evaluation.AppliedSlippagePrice;
            if (orderType is StandardOrderType.Stop or StandardOrderType.StopLimit)
            {
                _stopFillCount++;
                _totalStopSlippagePrice += evaluation.AppliedSlippagePrice;
            }
            if (evaluation.GapThroughStop) _gapFills++;
            if (evaluation.IsPartialFill) _partialFills++;
        }
    }

    private ProtectiveOrderReconciliation ReconcileProtectiveOrdersUnsafe(
        InstrumentKey instrument,
        BrokerPosition? remainingPosition,
        string filledOrderId)
    {
        var resized = new List<SimulatedOrder>();
        var cancelled = new List<SimulatedOrder>();
        SimulatedOrder[] protectiveOrders = _orders.Values
            .Where(candidate =>
                candidate.BrokerOrderId != filledOrderId &&
                candidate.IsOpen &&
                candidate.Request.Instrument == instrument &&
                !string.IsNullOrWhiteSpace(candidate.OcoGroupId) &&
                candidate.Request.Type is StandardOrderType.Stop or StandardOrderType.Limit)
            .ToArray();

        foreach (SimulatedOrder protective in protectiveOrders)
        {
            if (remainingPosition is null || protective.Request.Side == remainingPosition.Side)
            {
                protective.Status = "CANCELLED";
                cancelled.Add(protective.Copy());
                continue;
            }

            if (protective.FilledQuantity != 0m)
            {
                // Attached protective orders in this simulator are all-or-nothing. A partially
                // filled protective order cannot be resized safely, so keep it unchanged and let
                // the normal reconciliation/safety path surface the mismatch.
                continue;
            }

            if (protective.Request.Quantity.Value == remainingPosition.Quantity)
                continue;

            protective.Request = protective.Request with
            {
                Quantity = new OrderQuantity(
                    remainingPosition.Quantity,
                    protective.Request.Quantity.Unit)
            };
            resized.Add(protective.Copy());
        }

        return new ProtectiveOrderReconciliation(resized, cancelled);
    }

    private decimal ApplyPositionFillUnsafe(
        PlaceOrderRequest request,
        decimal signedFill,
        decimal fillPrice)
    {
        InstrumentKey instrument = request.Instrument;
        if (!_positions.TryGetValue(instrument, out MutablePosition? position))
        {
            _positions[instrument] = new MutablePosition(request, signedFill, fillPrice);
            return 0m;
        }

        decimal existing = position.SignedQuantity;
        if (Math.Sign(existing) == Math.Sign(signedFill))
        {
            decimal newQuantity = existing + signedFill;
            position.AveragePrice =
                ((Math.Abs(existing) * position.AveragePrice) + (Math.Abs(signedFill) * fillPrice)) /
                Math.Abs(newQuantity);
            position.SignedQuantity = newQuantity;
            return 0m;
        }

        decimal closingQuantity = Math.Min(Math.Abs(existing), Math.Abs(signedFill));
        decimal realised = existing > 0m
            ? (fillPrice - position.AveragePrice) * closingQuantity
            : (position.AveragePrice - fillPrice) * closingQuantity;

        decimal remaining = existing + signedFill;
        if (remaining == 0m)
        {
            _positions.Remove(instrument);
        }
        else if (Math.Sign(remaining) != Math.Sign(existing))
        {
            position.SignedQuantity = remaining;
            position.AveragePrice = fillPrice;
            position.AssignOwnership(request);
        }
        else
        {
            position.SignedQuantity = remaining;
        }

        return realised;
    }

    private BrokerPosition? GetPositionUnsafe(InstrumentKey instrument) =>
        _positions.TryGetValue(instrument, out MutablePosition? position)
            ? ToBrokerPositionUnsafe(position)
            : null;

    private BrokerPosition ToBrokerPositionUnsafe(MutablePosition position) => new()
    {
        PositionId = $"SIM-POS-{position.Instrument.Value}",
        StrategyId = position.StrategyId,
        DecisionId = position.DecisionId,
        SetupId = position.SetupId,
        PortfolioReservationId = position.PortfolioReservationId,
        RiskClusterId = position.RiskClusterId,
        Instrument = position.Instrument,
        Side = position.SignedQuantity >= 0m ? OrderSide.Buy : OrderSide.Sell,
        Quantity = Math.Abs(position.SignedQuantity),
        AveragePrice = position.AveragePrice,
        UnrealizedProfitLoss = CalculateUnrealisedUnsafe(position),
        Currency = _options.BaseCurrency
    };

    private decimal CalculateUnrealisedUnsafe(MutablePosition position)
    {
        if (!_latestCandles.TryGetValue(position.Instrument, out Candle? candle))
        {
            return 0m;
        }

        decimal mark = candle.Prices.Close;
        decimal quoteProfitLoss = position.SignedQuantity >= 0m
            ? (mark - position.AveragePrice) * Math.Abs(position.SignedQuantity)
            : (position.AveragePrice - mark) * Math.Abs(position.SignedQuantity);
        return quoteProfitLoss * GetQuoteToBaseCurrencyRateUnsafe(position.Instrument);
    }

    private decimal CalculateMarginUnsafe(MutablePosition position)
    {
        decimal mark = _latestCandles.TryGetValue(position.Instrument, out Candle? candle)
            ? candle.Prices.Close
            : position.AveragePrice;
        return Math.Abs(position.SignedQuantity) *
            mark *
            GetQuoteToBaseCurrencyRateUnsafe(position.Instrument) /
            _options.Leverage;
    }

    private static BrokerOrder ToBrokerOrder(SimulatedOrder order) => new()
    {
        BrokerOrderId = order.BrokerOrderId,
        ClientOrderId = order.ClientOrderId,
        StrategyId = order.Request.StrategyId,
        DecisionId = order.Request.DecisionId,
        SetupId = order.Request.SetupId,
        PortfolioReservationId = order.Request.PortfolioReservationId,
        RiskClusterId = order.Request.RiskClusterId,
        ReduceOnly = order.Request.ReduceOnly,
        Instrument = order.Request.Instrument,
        Side = order.Request.Side,
        Type = order.Request.Type.ToString(),
        Status = order.Status,
        NormalizedStatus = ToNormalizedStatus(order.Status),
        Quantity = order.Request.Quantity.Value,
        FilledQuantity = order.FilledQuantity,
        Price = order.Request.LimitPrice ?? order.Request.StopPrice,
        CreatedAt = order.SubmittedAt
    };

    private static int GetExecutionPhasePriority(SimulatedOrder order) =>
        order.Request.Type == StandardOrderType.Market ? 0 : 1;

    private int GetOcoExecutionPriority(SimulatedOrder order, decimal? candleOpen)
    {
        if (order.OcoGroupId is null)
        {
            return 0;
        }

        return (_options.OcoFillPolicy, order.Request.Type) switch
        {
            (OcoFillPolicy.StopLossFirst, StandardOrderType.Stop) => -1,
            (OcoFillPolicy.StopLossFirst, StandardOrderType.Limit) => 1,
            (OcoFillPolicy.TakeProfitFirst, StandardOrderType.Limit) => -1,
            (OcoFillPolicy.TakeProfitFirst, StandardOrderType.Stop) => 1,
            // Nearest uses secondary key; ties prefer stop (conservative).
            (OcoFillPolicy.NearestToOpenFirst, StandardOrderType.Stop) => -1,
            (OcoFillPolicy.NearestToOpenFirst, StandardOrderType.Limit) => 1,
            _ => 0
        };
    }

    private decimal GetNearestDistance(SimulatedOrder order, decimal? candleOpen)
    {
        if (_options.OcoFillPolicy != OcoFillPolicy.NearestToOpenFirst ||
            order.OcoGroupId is null ||
            candleOpen is not decimal open)
        {
            return 0m;
        }

        decimal? level = order.Request.Type == StandardOrderType.Stop
            ? order.Request.StopPrice
            : order.Request.LimitPrice;
        return level is decimal price ? Math.Abs(price - open) : decimal.MaxValue;
    }

    private string? GetMarginRejectionReasonUnsafe(
        SimulatedOrder order,
        decimal price,
        decimal quantity,
        decimal commission)
    {
        if (!_options.EnforceMarginRequirements)
        {
            return null;
        }

        decimal existingQuantity = _positions.TryGetValue(
            order.Request.Instrument,
            out MutablePosition? position)
            ? position.SignedQuantity
            : 0m;
        decimal signedFill = order.Request.Side == OrderSide.Buy ? quantity : -quantity;
        decimal additionalExposure = Math.Max(
            0m,
            Math.Abs(existingQuantity + signedFill) - Math.Abs(existingQuantity));

        if (additionalExposure == 0m)
        {
            return null;
        }

        decimal available = CalculateAvailableUnsafe(order.Request.Instrument, price);
        decimal required = additionalExposure *
            price *
            GetQuoteToBaseCurrencyRateUnsafe(order.Request.Instrument) /
            _options.Leverage +
            commission;
        return required > available
            ? $"Insufficient available margin. Required {required:F8} {_options.BaseCurrency}, " +
              $"available {available:F8} {_options.BaseCurrency}."
            : null;
    }

    private decimal CalculateAvailableUnsafe(InstrumentKey executionInstrument, decimal executionPrice)
    {
        decimal unrealised = 0m;
        decimal margin = 0m;
        foreach (MutablePosition position in _positions.Values)
        {
            decimal mark = position.Instrument == executionInstrument
                ? executionPrice
                : _latestCandles.TryGetValue(position.Instrument, out Candle? candle)
                    ? candle.Prices.Close
                    : position.AveragePrice;
            decimal positionProfitLoss = position.SignedQuantity >= 0m
                ? (mark - position.AveragePrice) * Math.Abs(position.SignedQuantity)
                : (position.AveragePrice - mark) * Math.Abs(position.SignedQuantity);
            decimal rate = GetQuoteToBaseCurrencyRateUnsafe(position.Instrument);
            unrealised += positionProfitLoss * rate;
            margin += Math.Abs(position.SignedQuantity) * mark * rate / _options.Leverage;
        }

        return CashBalance + unrealised - margin;
    }

    private static OrderStatus ToNormalizedStatus(string status) => status switch
    {
        "ACCEPTED" or "TRIGGERED" => OrderStatus.Open,
        "PARTIALLY_FILLED" => OrderStatus.PartiallyFilled,
        "FILLED" => OrderStatus.Filled,
        "CANCELLED" => OrderStatus.Cancelled,
        "REPLACED" => OrderStatus.Replaced,
        "REJECTED" => OrderStatus.Rejected,
        "EXPIRED" => OrderStatus.Expired,
        _ => OrderStatus.Unknown
    };

    private decimal GetQuoteToBaseCurrencyRateUnsafe(InstrumentKey instrument)
    {
        if (TryGetQuoteToBaseCurrencyRateUnsafe(instrument, out decimal rate, out string? error))
        {
            return rate;
        }

        throw new InvalidOperationException(error);
    }

    private bool TryGetQuoteToBaseCurrencyRateUnsafe(
        InstrumentKey instrument,
        out decimal rate,
        out string? error)
    {
        string value = instrument.Value;
        int prefix = value.IndexOf(':');
        string pair = prefix >= 0 ? value[(prefix + 1)..] : value;
        int separator = pair.LastIndexOfAny(['/', '_', '-']);
        if (separator < 0 || separator == pair.Length - 1)
        {
            rate = 0m;
            error = $"Instrument {instrument} does not expose a quote currency. " +
                "Use a canonical BASE/QUOTE instrument key.";
            return false;
        }

        string quoteCurrency = pair[(separator + 1)..];
        if (string.Equals(quoteCurrency, _options.BaseCurrency, StringComparison.OrdinalIgnoreCase))
        {
            rate = 1m;
            error = null;
            return true;
        }

        foreach ((string currency, decimal configuredRate) in _options.QuoteToBaseCurrencyRates)
        {
            if (string.Equals(currency, quoteCurrency, StringComparison.OrdinalIgnoreCase))
            {
                rate = configuredRate;
                error = null;
                return true;
            }
        }

        rate = 0m;
        error = $"No {quoteCurrency}-to-{_options.BaseCurrency} conversion rate is configured " +
            $"for {instrument}.";
        return false;
    }

    private void AddLedgerUnsafe(
        DateTimeOffset timestamp,
        LedgerEntryType type,
        decimal amount,
        string? orderId,
        string description)
    {
        _ledger.Add(new LedgerEntry
        {
            Sequence = ++_ledgerSequence,
            Timestamp = timestamp,
            Type = type,
            Amount = amount,
            Currency = _options.BaseCurrency,
            OrderId = orderId,
            Description = description
        });
    }

    private SimulatedOrder CreateOrderUnsafe(
        PlaceOrderRequest request,
        DateTimeOffset now,
        string? ocoGroupId = null)
    {
        SubmittedOrders++;
        string id = $"SIM-{++_orderSequence:D10}";
        var order = new SimulatedOrder
        {
            BrokerOrderId = id,
            ClientOrderId = request.ClientOrderId ?? id,
            Request = request,
            SubmittedAt = now,
            SubmittedMarketSequence = MarketSequence,
            Status = "ACCEPTED",
            OcoGroupId = ocoGroupId
        };
        _orders.Add(id, order);
        return order.Copy();
    }

    private string? ValidateProtectiveStopAmendmentUnsafe(AmendProtectiveStopRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ClientAmendmentId) ||
            string.IsNullOrWhiteSpace(request.PositionId) ||
            request.Instrument.IsEmpty)
        {
            return "Amendment ID, position ID, and instrument are required.";
        }
        if (request.CurrentStopPrice <= 0m || request.NewStopPrice <= 0m ||
            request.CurrentExecutablePrice <= 0m || request.PositionQuantity <= 0m ||
            request.MinimumPriceIncrement <= 0m)
        {
            return "Stop, executable price, quantity, and price increment must be positive.";
        }
        if (request.NewStopPrice % request.MinimumPriceIncrement != 0m)
            return "The proposed stop does not conform to the instrument price increment.";
        if (request.EffectiveFromExecutionSequence <= MarketSequence)
            return "A replacement stop must become effective after the current execution sequence.";
        if (!_positions.TryGetValue(request.Instrument, out MutablePosition? position))
            return "The position is already closed or does not exist.";

        BrokerPosition actualPosition = ToBrokerPositionUnsafe(position);
        if (!string.Equals(actualPosition.PositionId, request.PositionId, StringComparison.Ordinal))
            return "The amendment position ID does not match the open position.";
        if (actualPosition.Side != request.PositionSide)
            return "The amendment position side does not match the open position.";
        if (actualPosition.Quantity != request.PositionQuantity)
            return "The amendment quantity does not match the open position.";
        if (string.IsNullOrWhiteSpace(request.ExistingStopOrderId) ||
            !_orders.TryGetValue(request.ExistingStopOrderId, out SimulatedOrder? stop) ||
            !stop.IsOpen)
        {
            return "The existing protective-stop order ID is stale or inactive.";
        }
        if (stop.Request.Instrument != request.Instrument ||
            stop.Request.Type != StandardOrderType.Stop ||
            stop.Request.Quantity.Value != request.PositionQuantity ||
            stop.Request.Side == request.PositionSide)
        {
            return "The existing order does not match the position's protective stop.";
        }
        if (stop.Request.StopPrice != request.CurrentStopPrice)
            return "The current stop price is stale.";

        bool riskReducing = request.PositionSide switch
        {
            OrderSide.Buy => request.NewStopPrice > request.CurrentStopPrice &&
                request.NewStopPrice < request.CurrentExecutablePrice,
            OrderSide.Sell => request.NewStopPrice < request.CurrentStopPrice &&
                request.NewStopPrice > request.CurrentExecutablePrice,
            _ => false
        };
        return riskReducing
            ? null
            : "The proposed stop is not a risk-reducing price on the valid side of the executable market.";
    }

    private SimulatedProtectiveStopReplacement RejectedReplacement(
        AmendProtectiveStopRequest request,
        string reason)
    {
        _rejectedAmendments++;
        return new SimulatedProtectiveStopReplacement(
        new ProtectiveStopAmendmentResult
        {
            Status = ProtectiveStopAmendmentStatus.Rejected,
            ClientAmendmentId = request.ClientAmendmentId,
            PreviousStopOrderId = request.ExistingStopOrderId,
            CurrentStopOrderId = request.ExistingStopOrderId,
            RequestedStopPrice = request.NewStopPrice,
            RejectionReason = reason,
            Certainty = ExecutionCertainty.Rejected
        },
        null,
        null,
        IsReplay: false);
    }

    private sealed class MutablePosition(
        PlaceOrderRequest request,
        decimal signedQuantity,
        decimal averagePrice)
    {
        public InstrumentKey Instrument { get; } = request.Instrument;
        public decimal SignedQuantity { get; set; } = signedQuantity;
        public decimal AveragePrice { get; set; } = averagePrice;
        public string? StrategyId { get; private set; } = request.StrategyId;
        public string? DecisionId { get; private set; } = request.DecisionId;
        public string? SetupId { get; private set; } = request.SetupId;
        public string? PortfolioReservationId { get; private set; } = request.PortfolioReservationId;
        public string? RiskClusterId { get; private set; } = request.RiskClusterId;

        public void AssignOwnership(PlaceOrderRequest replacement)
        {
            StrategyId = replacement.StrategyId;
            DecisionId = replacement.DecisionId;
            SetupId = replacement.SetupId;
            PortfolioReservationId = replacement.PortfolioReservationId;
            RiskClusterId = replacement.RiskClusterId;
        }
    }
}

public sealed class SimulatedOrder
{
    public required string BrokerOrderId { get; init; }
    public required string ClientOrderId { get; init; }
    public required PlaceOrderRequest Request { get; set; }
    public required DateTimeOffset SubmittedAt { get; init; }
    public required long SubmittedMarketSequence { get; set; }
    public required string Status { get; set; }
    public decimal FilledQuantity { get; set; }
    public bool IsTriggered { get; set; }
    public string? OcoGroupId { get; init; }
    public bool IsOpen => Status is "ACCEPTED" or "TRIGGERED" or "PARTIALLY_FILLED";

    public SimulatedOrder Copy() => (SimulatedOrder)MemberwiseClone();
}

internal sealed record FillApplicationResult(
    SimulatedOrder Order,
    decimal RealisedProfitLoss,
    decimal Commission,
    BrokerPosition? Position,
    IReadOnlyList<SimulatedOrder> ResizedProtectiveOrders,
    IReadOnlyList<SimulatedOrder> CancelledProtectiveOrders,
    decimal FilledQuantity);

internal sealed record ProtectiveOrderReconciliation(
    IReadOnlyList<SimulatedOrder> ResizedOrders,
    IReadOnlyList<SimulatedOrder> CancelledOrders)
{
    public static ProtectiveOrderReconciliation Empty { get; } = new([], []);
}

internal sealed record SimulatedProtectiveStopReplacement(
    ProtectiveStopAmendmentResult Result,
    SimulatedOrder? PreviousOrder,
    SimulatedOrder? CurrentOrder,
    bool IsReplay);

internal sealed record SimulatedAmendmentReceipt(
    AmendProtectiveStopRequest Request,
    ProtectiveStopAmendmentResult Result);
